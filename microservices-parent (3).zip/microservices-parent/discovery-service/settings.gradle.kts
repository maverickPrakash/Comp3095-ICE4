rootProject.name = "discovery-service"
